<?php

namespace App\Http\Livewire\Includes;

use Livewire\Component;

class FooterWide extends Component
{
    public function render()
    {
        return view('livewire.includes.footer-wide');
    }
}
