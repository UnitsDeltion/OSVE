<?php

namespace App\Http\Livewire\Includes;

use Livewire\Component;

class Footer extends Component
{
    public function render()
    {
        return view('livewire.includes.footer');
    }
}
