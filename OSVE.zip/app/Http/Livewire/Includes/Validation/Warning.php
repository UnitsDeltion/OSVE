<?php

namespace App\Http\Livewire\Includes\Validation;

use Livewire\Component;

class Warning extends Component
{
    public function render()
    {
        return view('livewire.includes.validation.warning');
    }
}
