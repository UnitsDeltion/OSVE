<?php

namespace App\Http\Livewire\Includes\Content\Bottom;

use Livewire\Component;

class ContentBottom extends Component
{
    public function render()
    {
        return view('livewire.includes.content.bottom.content-bottom');
    }
}
