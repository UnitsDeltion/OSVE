<?php

namespace App\Http\Livewire\Includes\Content\Top;

use Livewire\Component;

class ContentNormalTop extends Component
{
    public function render()
    {
        return view('livewire.includes.content.top.content-normal-top');
    }
}
