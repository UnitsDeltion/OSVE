<?php

namespace App\Http\Livewire\Includes\Content\Top;

use Livewire\Component;

class ContentXSmallTop extends Component
{
    public function render()
    {
        return view('livewire.includes.content.top.content-x-small-top');
    }
}
