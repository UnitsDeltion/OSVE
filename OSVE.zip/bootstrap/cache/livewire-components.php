<?php return array (
  'includes.breadcrumbs' => 'App\\Http\\Livewire\\Includes\\Breadcrumbs',
  'includes.content.bottom.content-bottom' => 'App\\Http\\Livewire\\Includes\\Content\\Bottom\\ContentBottom',
  'includes.content.top.content-full-top' => 'App\\Http\\Livewire\\Includes\\Content\\Top\\ContentFullTop',
  'includes.content.top.content-normal-top' => 'App\\Http\\Livewire\\Includes\\Content\\Top\\ContentNormalTop',
  'includes.content.top.content-small-top' => 'App\\Http\\Livewire\\Includes\\Content\\Top\\ContentSmallTop',
  'includes.content.top.content-wide-top' => 'App\\Http\\Livewire\\Includes\\Content\\Top\\ContentWideTop',
  'includes.content.top.content-x-small-top' => 'App\\Http\\Livewire\\Includes\\Content\\Top\\ContentXSmallTop',
  'includes.footer' => 'App\\Http\\Livewire\\Includes\\Footer',
  'includes.footer-wide' => 'App\\Http\\Livewire\\Includes\\FooterWide',
  'includes.validation.input' => 'App\\Http\\Livewire\\Includes\\Validation\\Input',
  'includes.validation.warning' => 'App\\Http\\Livewire\\Includes\\Validation\\Warning',
);