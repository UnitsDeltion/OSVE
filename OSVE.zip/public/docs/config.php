<?php

return array(
    'docVersion'        => '3.0',
    'docGemaakt'        => '11-11-2021',
    'docBijgewerkt'     => '19-12-2021',
    'OSVEVersion'       => '3.0',
    'OSVEGemaakt'       => '5-10-2021',
    'OSVEBijgewerkt'    => '19-12-2021',
);