<section id="models">
    <h2>Models</h2>

    <div id="models_Account">
        <h3>Account</h3>
        <p class="mb-0"></p>
        <pre>
            <code class="php">
<?php import('../../app/Models/Account.php') ?>
            </code>
        </pre>
    </div>
        
    <div id="models_Examen">
        <h3>Examen</h3>
        <p class="mb-0"></p>
        <pre>
            <code class="php">
<?php import('../../app/Models/Examen.php') ?>
            </code>
        </pre>
    </div>

    <div id="models_ExamenMoment">
        <h3>ExamenMoment</h3>
        <p class="mb-0"></p>
        <pre>
            <code class="php">
<?php import('../../app/Models/ExamenMoment.php') ?>
            </code>
        </pre>
    </div>

    <div id="models_GeplandeExamens">
        <h3>GeplandeExamens</h3>
        <p class="mb-0"></p>
        <pre>
            <code class="php">
<?php import('../../app/Models/GeplandeExamens.php') ?>
            </code>
        </pre>
    </div>

    <div id="models_GeplandeExamensTokens">
        <h3>GeplandeExamensTokens</h3>
        <p class="mb-0"></p>
        <pre>
            <code class="php">
<?php import('../../app/Models/GeplandeExamensTokens.php') ?>
            </code>
        </pre>
    </div>

    <div id="models_Opleidingen">
        <h3>Opleidingen</h3>
        <p class="mb-0"></p>
        <pre>
            <code class="php">
<?php import('../../app/Models/Opleidingen.php') ?>
            </code>
        </pre>
    </div>

    <div id="models_ReglementenBeheer">
        <h3>ReglementenBeheer</h3>
        <p class="mb-0"></p>
        <pre>
            <code class="php">
<?php import('../../app/Models/ReglementenBeheer.php') ?>
            </code>
        </pre>
    </div>
        
    <div id="models_User">
        <h3>User</h3>
        <p class="mb-0"></p>
        <pre>
            <code class="php">
<?php import('../../app/Models/User.php') ?>
            </code>
        </pre>
    </div>
</section>