<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex" style="width: 100%;">
            <h2 class="align-self-start font-semibold text-xl text-gray-800 leading-tight row">
                <?php $__env->startSection('title', 'Alle gebruikers'); ?>
                <?php echo $__env->yieldContent('title'); ?>
            </h2>
            <a href="<?php echo e(route('users.create')); ?>" class="a-clear" style="margin-right: 0; margin-left: auto;">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button']); ?>
                    <?php echo e(__('Gebruiker toevoegen')); ?>

                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('17MdMBL')) {
    $componentId = $_instance->getRenderedChildComponentId('17MdMBL');
    $componentTag = $_instance->getRenderedChildComponentTagName('17MdMBL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('17MdMBL');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('17MdMBL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show mb-10" role="alert">
            <p class="mb-0"><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table mt-4">
        <thead>
            <tr>
                <th>Naam</th>
                <th>Email</th>
                <th colspan="2"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="va-middle">
                    <td><?php echo e($user->voornaam); ?> <?php echo e($user->achternaam); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td class="align-right pr-0">
                        <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="mr-2 a-clear">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button']); ?>
                                <i class="fas fa-edit"></i>
                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </a>
                    </td>
                    <td>
                        <a data-toggle="modal" id="largeButton" data-target="#largeModal" data-attr="<?php echo e(route('usersDelete', $user->id)); ?>" title="Delete User">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','title' => 'Verwijderen']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','title' => 'Verwijderen']); ?>
                                    <i class="fas fa-trash"></i>
                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

     <!-- large modal -->
    <div class="modal fade" id="largeModal" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="largeBody">
                    <div>
                        <!-- body content -->
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
    // display delete modal
    $(document).on('click', '#largeButton', function(event) {
        event.preventDefault();
        let href = $(this).attr('data-attr');
        $.ajax({
            url: href
            , beforeSend: function() {
                $('#loader').show();
            },
            // return the result
            success: function(result) {
                $('#largeModal').modal("show");
                $('#largeBody').html(result).show();
            }
            , complete: function() {
                $('#loader').hide();
            }
            , error: function(jqXHR, testStatus, error) {
                console.log(error);
                alert("Page " + href + " cannot open. Error:" + error);
                $('#loader').hide();
            }
            , timeout: 8000
        })
    });

</script>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('ohdrAVu')) {
    $componentId = $_instance->getRenderedChildComponentId('ohdrAVu');
    $componentTag = $_instance->getRenderedChildComponentTagName('ohdrAVu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ohdrAVu');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('ohdrAVu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/users/index.blade.php ENDPATH**/ ?>