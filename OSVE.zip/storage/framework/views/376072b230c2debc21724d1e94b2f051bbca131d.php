<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight r-title-big">
            Opgave systeem voor examens
        </h2>
        <h2 class="font-semibold text-xl text-gray-800 leading-tight r-title-small align-center">
            OSVE
        </h2>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.warning')->html();
} elseif ($_instance->childHasBeenRendered('OoBhaAj')) {
    $componentId = $_instance->getRenderedChildComponentId('OoBhaAj');
    $componentTag = $_instance->getRenderedChildComponentTagName('OoBhaAj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OoBhaAj');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.warning');
    $html = $response->html();
    $_instance->logRenderedChild('OoBhaAj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('aX8lVYf')) {
    $componentId = $_instance->getRenderedChildComponentId('aX8lVYf');
    $componentTag = $_instance->getRenderedChildComponentTagName('aX8lVYf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aX8lVYf');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('aX8lVYf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })    
    </script>

        <div class="containter mt-5 mb-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <h3>Persoonlijke gegevens</h3>

                    <form method="POST" action="<?php echo e(url('f2')); ?>">

                        <?php echo csrf_field(); ?>
                    
                        <div class="mb-3">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'voornaam','value' => ''.e(__('Voornaam')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'voornaam','value' => ''.e(__('Voornaam')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['id' => 'voornaam','class' => 'block mt-1 w-full','type' => 'text','name' => 'voornaam','value' => old('voornaam'),'autofocus' => true]]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'voornaam','class' => 'block mt-1 w-full','type' => 'text','name' => 'voornaam','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('voornaam')),'autofocus' => true]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'voornaam'])->html();
} elseif ($_instance->childHasBeenRendered('R5m93ms')) {
    $componentId = $_instance->getRenderedChildComponentId('R5m93ms');
    $componentTag = $_instance->getRenderedChildComponentTagName('R5m93ms');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('R5m93ms');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'voornaam']);
    $html = $response->html();
    $_instance->logRenderedChild('R5m93ms', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>

                        <div class="mb-3">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'achternaam','value' => ''.e(__('Achternaam')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'achternaam','value' => ''.e(__('Achternaam')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['id' => 'achternaam','class' => 'block mt-1 w-full','type' => 'text','name' => 'achternaam','value' => old('achternaam')]]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'achternaam','class' => 'block mt-1 w-full','type' => 'text','name' => 'achternaam','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('achternaam'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'achternaam'])->html();
} elseif ($_instance->childHasBeenRendered('PcsDwMV')) {
    $componentId = $_instance->getRenderedChildComponentId('PcsDwMV');
    $componentTag = $_instance->getRenderedChildComponentTagName('PcsDwMV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PcsDwMV');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'achternaam']);
    $html = $response->html();
    $_instance->logRenderedChild('PcsDwMV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>

                        <div class="mb-3">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'studentnummer','value' => ''.e(__('Studentnummer')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'studentnummer','value' => ''.e(__('Studentnummer')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['id' => 'studentnummer','class' => 'block mt-1 w-full','type' => 'number','name' => 'studentnummer','value' => old('studentnummer')]]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'studentnummer','class' => 'block mt-1 w-full','type' => 'number','name' => 'studentnummer','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('studentnummer'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'studentnummer'])->html();
} elseif ($_instance->childHasBeenRendered('sfY88aT')) {
    $componentId = $_instance->getRenderedChildComponentId('sfY88aT');
    $componentTag = $_instance->getRenderedChildComponentTagName('sfY88aT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sfY88aT');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'studentnummer']);
    $html = $response->html();
    $_instance->logRenderedChild('sfY88aT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        
                        <div class="mb-3">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'klas','value' => ''.e(__('Klas')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'klas','value' => ''.e(__('Klas')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['id' => 'klas','class' => 'block mt-1 w-full','type' => 'text','name' => 'klas','value' => old('klas')]]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'klas','class' => 'block mt-1 w-full','type' => 'text','name' => 'klas','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('klas'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'klas'])->html();
} elseif ($_instance->childHasBeenRendered('IzMFXkn')) {
    $componentId = $_instance->getRenderedChildComponentId('IzMFXkn');
    $componentTag = $_instance->getRenderedChildComponentTagName('IzMFXkn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IzMFXkn');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'klas']);
    $html = $response->html();
    $_instance->logRenderedChild('IzMFXkn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div> 

                        <div class="mb-3">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'faciliteitenpas']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'faciliteitenpas']); ?><?php echo e(__('Faciliteitenpas')); ?> <i class="fas fa-info-circle" id="tooltipFaciliteitenpas" data-toggle="tooltip" data-bs-placement="bottom" title="Heb je dyslexie of een ander leerprobleem? Dan kom je mogelijk in aanmerking voor een faciliteitenpas. Hiermee krijg je (extra) hulpmiddelen en maatregelen bij het maken van toetsen en examens bijvoorbeeld."></i> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <select name="faciliteitenpas" id="faciliteitenpas" class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm block mt-1 w-full">
                                <option value="Nee" selected>Nee</option>
                                <option value="Ja">Ja</option>
                            </select>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'faciliteitenpas'])->html();
} elseif ($_instance->childHasBeenRendered('11sM1K5')) {
    $componentId = $_instance->getRenderedChildComponentId('11sM1K5');
    $componentTag = $_instance->getRenderedChildComponentTagName('11sM1K5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('11sM1K5');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'faciliteitenpas']);
    $html = $response->html();
    $_instance->logRenderedChild('11sM1K5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>

                        <div class="mt-4">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                                Verder <i class="fas fa-forward ml-2"></i> 
                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>   
        
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('VJqZBrp')) {
    $componentId = $_instance->getRenderedChildComponentId('VJqZBrp');
    $componentTag = $_instance->getRenderedChildComponentTagName('VJqZBrp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VJqZBrp');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('VJqZBrp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\School\PROJ\OSVE\resources\views/p1.blade.php ENDPATH**/ ?>