<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

    <?php
        $route = Route::current();
        $name = $route->getName();
    ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.breadcrumbs', ['page' => $name])->html();
} elseif ($_instance->childHasBeenRendered('WXsznMc')) {
    $componentId = $_instance->getRenderedChildComponentId('WXsznMc');
    $componentTag = $_instance->getRenderedChildComponentTagName('WXsznMc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WXsznMc');
} else {
    $response = \Livewire\Livewire::mount('includes.breadcrumbs', ['page' => $name]);
    $html = $response->html();
    $_instance->logRenderedChild('WXsznMc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-10">
                        <div class="content"><?php /**PATH C:\School\PROJ\OSVE\resources\views/livewire/includes/content/top/content-normal-top.blade.php ENDPATH**/ ?>