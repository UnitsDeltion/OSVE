<a href="/">
	<img class="h-20" src="<?php echo e(asset('images/logos/logo.svg')); ?>" />
</a>

<?php /**PATH C:\School\PROJ\OSVE\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>