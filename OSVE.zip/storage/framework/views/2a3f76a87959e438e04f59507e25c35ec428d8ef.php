<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight r-title-big">
            Opgave systeem voor examens
        </h2>
        <h2 class="font-semibold text-xl text-gray-800 leading-tight r-title-small align-center">
            OSVE
        </h2>
     <?php $__env->endSlot(); ?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-small-top')->html();
} elseif ($_instance->childHasBeenRendered('xMemIxS')) {
    $componentId = $_instance->getRenderedChildComponentId('xMemIxS');
    $componentTag = $_instance->getRenderedChildComponentTagName('xMemIxS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xMemIxS');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-small-top');
    $html = $response->html();
    $_instance->logRenderedChild('xMemIxS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  

    <div class="container">
        <div class="row">
            <div class="mt-40">
                <h3 class="align-center">Controleer je e-mail!</h3>
                <h5 class="align-center">Voordat het examen definitief is ingepland moet deze eerst worden bevestigd. <br> Er is een e-mail verstuurd naar <span class="fc-secondary-nh"><?php echo e($studentnummer); ?>@st.deltion.nl</span>. Gebruik de link in de e-mail om het examen te bevestigen.</h5>

                <h5 class="align-center fc-red mt-4 mb-0-r"><strong>Let op!</strong></h5>
                <h5 class="align-center">Je hebt 24 uur om het examen te bevestigen. Na deze 24 uur wordt de gereserveerde plek weer vrijgegeven.</h5>
            </div>
            <form method="post" class="text-center" action="<?php echo e(route('ics_handler')); ?>">
                <?php echo csrf_field(); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button mt-15']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button mt-15']); ?>
                    Download afspraak <i class="fas fa-download ml-2"></i> 
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </form>
        </div>
    </div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('ezUn7tk')) {
    $componentId = $_instance->getRenderedChildComponentId('ezUn7tk');
    $componentTag = $_instance->getRenderedChildComponentTagName('ezUn7tk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ezUn7tk');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('ezUn7tk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\School\PROJ\OSVE\resources\views/p6.blade.php ENDPATH**/ ?>