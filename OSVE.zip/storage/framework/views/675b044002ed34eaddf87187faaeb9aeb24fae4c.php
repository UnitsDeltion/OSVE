<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php $__env->startSection('title', 'Privacyverklaring'); ?>
            <?php echo $__env->yieldContent('title'); ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-wide-top')->html();
} elseif ($_instance->childHasBeenRendered('FMFtynV')) {
    $componentId = $_instance->getRenderedChildComponentId('FMFtynV');
    $componentTag = $_instance->getRenderedChildComponentTagName('FMFtynV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FMFtynV');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-wide-top');
    $html = $response->html();
    $_instance->logRenderedChild('FMFtynV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

        <div class="privacy-policy-content">
            <p>Deltion College gaat zorgvuldig om met jouw gegevens. Hieronder vertellen we hoe we dat doen.</p>

            <h3>Cookies, of vergelijkbare technieken</h3>
            <p>Een cookie is een bestandje dat op de harde schijf van je computer wordt opgeslagen. Deltion maakt gebruik van cookies op haar websites. We mogen volgens de wet cookies op je apparaat opslaan als ze strikt noodzakelijk zijn. Daarom staat deze optie al aangevinkt. Voor alle andere soorten cookies hebben we je toestemming nodig. Deze toestemming gaat om het gebruiken van marketing en statistieken cookies. Zo kunnen we onze informatie zo goed mogelijk op jou afstemmen.</p>
            
            <p>Het gebeurt soms dat cookies worden verzameld via media van derden, zoals bij het bekijken van een YouTube-film die via onze site wordt getoond. Deltion is niet verantwoordelijk voor de inhoud van websites van derden. Maar, als we filmpjes in deze site tonen, schakelen we daar wel de privacyvriendelijke instellingen in.</p>
            
            <p>Je kunt cookies ook zelf blokkeren en verwijderen via je internetbrowser. Ook kun je je internetbrowser zo instellen dat je een bericht ontvangt als er een cookie wordt geplaatst. Je kunt ook aangeven dat bepaalde cookies niet geplaatst mogen worden. Bekijk voor deze mogelijkheid de helpfunctie van je browser. Als je de cookies in je browser verwijdert, kan dat gevolgen hebben voor het gebruik van deze website. Op <a href="https://www.youronlinechoices.com/be-nl/">youronlinechoices.com/nl/</a> lees je meer over cookies en hoe je ze centraal kunt verwijderen.</p>

            <h3>Beeldmateriaal</h3>
            <p>Bij evenementen en schoolactiviteiten van Deltion wordt soms beeldmateriaal door ons gemaakt, dat op onze website of sociale media kan worden geplaatst. Het gaat daarbij steeds om algemene beelden (geen close-up’s). Als je bezwaar hebt tegen een foto op de website, stuur dan een bericht aan <a href="mailto:privacy@deltion.nl">privacy@deltion.nl</a>.</p>
            
            <h3>Studenten</h3>
            <p>Als je bij Deltion komt studeren, hebben wij gegevens van je nodig. Hier lees je hoe dat precies gaat en wat wij met je gegevens doen. Alle persoonlijke gegevens die wij van je nodig hebben, worden zorgvuldig verwerkt volgens de geldende wetgeving (Algemene Verordening Gegevensbescherming).</p>

            <h3>Persoonsgegevens die wij van je verwerken</h3>
            <p class="mb-0">Als je bij ons studeert, hebben we voor verschillende doeleinden persoonsgegevens van je nodig. Dat gaat om:</p>
            <ul>
                <li>het geven van studieadviezen;</li>
                <li>het komen tot een Onderwijsovereenkomst (OOK) en/of het komen tot een Praktijkovereenkomst (POK);</li>
                <li>het afleggen van verantwoording aan DUO, de onderwijsinspectie en de accountant;</li>
                <li>het aanschaffen van leermiddelen;</li>
                <li>het geven van je opleiding (lessen, toetsen, voortgang, aanwezigheidsregistratie);</li>
                <li>het innen van vergoedingen, lesgelden;</li>
                <li>het verwerken voor alumni-doeleinden;</li>
                <li>het gebruiken en beheren van onze ICT-voorzieningen;</li>
                <li>het bekendmaken van onderwijs-gerelateerde activiteiten;</li>
                <li>het behandelen van geschillen;</li>
                <li>het maken van een toegangspas.</li>
            </ul>

            <p>Wij verzamelen uitsluitend gegevens die nodig zijn voor het onderwijs dat je bij ons volgt en/of de diensten die we aan jou verlenen.</p>

            <h3>Waarvoor wij je persoonsgegevens gebruiken</h3>
            <p class="mb-0">Wij hebben jouw gegevens bijvoorbeeld nodig voor:</p>
            <ul>
                <li>Voor- en achternaam</li>
                <li>Adresgegevens</li>
                <li>Telefoonnummer</li>
                <li>E-mailadres</li>
                <li>IP-adres</li>
                <li>Locatiegegevens</li>
                <li>Gegevens over uw activiteiten op onze website</li>
                <li>Gegevens over uw surfgedrag over verschillende websites heen (bijvoorbeeld omdat dit bedrijf onderdeel is van een advertentienetwerk)</li>
                <li>Internetbrowser en apparaat type</li>
            </ul>

            <h3>Delen van persoonsgegevens met derden</h3>
            <p>De Dissel verstrekt uitsluitend aan derden en alleen als dit nodig is voor de uitvoering van onze overeenkomst met u of om te voldoen aan een wettelijke verplichting.</p>

            <h3>Cookies, of vergelijkbare technieken, die wij gebruiken</h3>
            <p>De Dissel gebruikt functionele, analytische en tracking cookies. Een cookie is een klein tekstbestand dat bij het eerste bezoek aan deze website wordt opgeslagen in de browser van uw computer, tablet of smartphone. De Dissel gebruikt cookies met een puur technische functionaliteit. Deze zorgen ervoor dat de website naar behoren werkt en dat bijvoorbeeld uw voorkeursinstellingen onthouden worden. Deze cookies worden ook gebruikt om de website goed te laten werken en deze te kunnen optimaliseren. Daarnaast plaatsen we cookies die uw surfgedrag bijhouden zodat we op maat gemaakte content en advertenties kunnen aanbieden. Bij uw eerste bezoek aan onze website hebben wij u al geïnformeerd over deze cookies en toestemming gevraagd voor het plaatsen ervan. U kunt zich afmelden voor cookies door uw internetbrowser zo in te stellen dat deze geen cookies meer opslaat. Daarnaast kunt u ook alle informatie die eerder is opgeslagen via de instellingen van uw browser verwijderen. Zie voor een toelichting: <a href="https://veiliginternetten.nl/themes/situatie/cookies-wat-zijn-het-en-wat-doe-ik-ermee/">https://veiliginternetten.nl/themes/situatie/cookies-wat-zijn-het-en-wat-doe-ik-ermee/</a>.</p>

            <h3>Gegevens inzien, aanpassen of verwijderen</h3>
            <p>U heeft het recht om uw persoonsgegevens in te zien, te corrigeren of te verwijderen. Dit kunt u zelf doen via de persoonlijke instellingen van uw account. Daarnaast heeft u het recht om uw eventuele toestemming voor de gegevensverwerking in te trekken of bezwaar te maken tegen de verwerking van uw persoonsgegevens door ons bedrijf en heeft u het recht op gegevensoverdraagbaarheid. Dat betekent dat u bij ons een verzoek kunt indienen om de persoonsgegevens die wij van u beschikken in een computerbestand naar u of een ander, door u genoemde organisatie, te sturen. Wilt u gebruik maken van uw recht op bezwaar en/of recht op gegevensoverdraagbaarheid of heeft u andere vragen/opmerkingen over de gegevensverwerking, stuur dan een gespecificeerd verzoek naar support@dedissel.nl. Om er zeker van te zijn dat het verzoek tot inzage door u is gedaan, vragen wij u een kopie van uw identiteitsbewijs bij het verzoek mee te sturen. Maak in deze kopie uw pasfoto, MRZ (machine readable zone, de strook met nummers onderaan het paspoort), paspoortnummer en Burgerservicenummer (BSN) zwart. Dit ter bescherming van uw privacy. De Dissel zal zo snel mogelijk, maar in ieder geval binnen vier weken, op uw verzoek reageren. De Dissel wil u er tevens op wijzen dat u de mogelijkheid hebt om een klacht in te dienen bij de nationale toezichthouder, de Autoriteit Persoonsgegevens. Dat kan via de volgende link: <a href="https://autoriteitpersoonsgegevens.nl/nl/contact-met-de-autoriteit-persoonsgegevens/tip-ons">https://autoriteitpersoonsgegevens.nl/nl/contact-met-de-autoriteit-persoonsgegevens/tip-ons</a>.</p>

            <h3>Hoe wij persoonsgegevens beveiligen</h3>
            <p>De Dissel neemt de bescherming van uw gegevens serieus en neemt passende maatregelen om misbruik, verlies, onbevoegde toegang, ongewenste openbaarmaking en ongeoorloofde wijziging tegen te gaan. Als u de indruk heeft dat uw gegevens niet goed beveiligd zijn of er aanwijzingen zijn van misbruik, neem dan contact op met onze klantenservice of via <a mailto="support@dedissel.nl">support@dedissel.nl</a>.</p>

            <small><i>Laatst bijgewerkt: 17-09-2021 19:45</i></small>
        </div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('lX9BX7D')) {
    $componentId = $_instance->getRenderedChildComponentId('lX9BX7D');
    $componentTag = $_instance->getRenderedChildComponentTagName('lX9BX7D');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lX9BX7D');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('lX9BX7D', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>     

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\School\PROJ\OSVE\resources\views/paginas/policy.blade.php ENDPATH**/ ?>