<a href="/">
	<img class="h-20" src="<?php echo e(asset('images/logos/logo.svg')); ?>" />
</a>

<?php /**PATH C:\School\PROJ\OSVE\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>