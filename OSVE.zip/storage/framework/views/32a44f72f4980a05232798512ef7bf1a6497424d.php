<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex" style="width: 100%;">
            <h2 class="align-self-start font-semibold text-xl text-gray-800 leading-tight row">
                <?php $__env->startSection('title', 'Reglementen beheer'); ?>
                <?php echo $__env->yieldContent('title'); ?>
            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.warning')->html();
} elseif ($_instance->childHasBeenRendered('OT8oU2E')) {
    $componentId = $_instance->getRenderedChildComponentId('OT8oU2E');
    $componentTag = $_instance->getRenderedChildComponentTagName('OT8oU2E');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OT8oU2E');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.warning');
    $html = $response->html();
    $_instance->logRenderedChild('OT8oU2E', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('EezgaAL')) {
    $componentId = $_instance->getRenderedChildComponentId('EezgaAL');
    $componentTag = $_instance->getRenderedChildComponentTagName('EezgaAL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EezgaAL');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('EezgaAL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mb-10" role="alert">
                <p class="mb-0"><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('reglementen.store')); ?>" class="mt-10">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <lable for="reglementen" class="block font-medium text-sm text-gray-700">Reglementen URL</lable>
                <input id="reglementen" class="block mt-1 w-full form-control" type="text" name="regelement" value="<?php echo e($reglementen->reglementen); ?>"/>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'reglementen'])->html();
} elseif ($_instance->childHasBeenRendered('nfZ4ciG')) {
    $componentId = $_instance->getRenderedChildComponentId('nfZ4ciG');
    $componentTag = $_instance->getRenderedChildComponentTagName('nfZ4ciG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nfZ4ciG');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'reglementen']);
    $html = $response->html();
    $_instance->logRenderedChild('nfZ4ciG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>

            <div class="mt-4">
                <a href="<?php echo e(route('dashboard.index')); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                    <i class="fas fa-backward mr-2"></i> Terug
                </a>
                
                <div class="form-group">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                        Opslaan <i class="fas fa-forward ml-2"></i> 
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </div>
                
        </form>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('e3XP4Fp')) {
    $componentId = $_instance->getRenderedChildComponentId('e3XP4Fp');
    $componentTag = $_instance->getRenderedChildComponentTagName('e3XP4Fp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('e3XP4Fp');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('e3XP4Fp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/reglementen/index.blade.php ENDPATH**/ ?>