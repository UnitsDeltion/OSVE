<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex" style="width: 100%;">
            <h2 class="align-self-start font-semibold text-xl text-gray-800 leading-tight row">
                <?php $__env->startSection('title', 'Nieuwe examen toevoegen'); ?>
                <?php echo $__env->yieldContent('title'); ?>
            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.warning')->html();
} elseif ($_instance->childHasBeenRendered('c4RBYDg')) {
    $componentId = $_instance->getRenderedChildComponentId('c4RBYDg');
    $componentTag = $_instance->getRenderedChildComponentTagName('c4RBYDg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('c4RBYDg');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.warning');
    $html = $response->html();
    $_instance->logRenderedChild('c4RBYDg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('6hmLTLi')) {
    $componentId = $_instance->getRenderedChildComponentId('6hmLTLi');
    $componentTag = $_instance->getRenderedChildComponentTagName('6hmLTLi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6hmLTLi');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('6hmLTLi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

        <form method="post" action="<?php echo e(route('examens.store')); ?>">

            <?php echo csrf_field(); ?>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="vak" class="block font-medium text-sm text-gray-700">Vak</lable>
                        <input id="vak" class="block mt-1 w-full form-control" type="text" name="vak" :value="old('vak')"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'vak'])->html();
} elseif ($_instance->childHasBeenRendered('nWe2tQW')) {
    $componentId = $_instance->getRenderedChildComponentId('nWe2tQW');
    $componentTag = $_instance->getRenderedChildComponentTagName('nWe2tQW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nWe2tQW');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'vak']);
    $html = $response->html();
    $_instance->logRenderedChild('nWe2tQW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="examen" class="block font-medium text-sm text-gray-700">Examen</lable>
                        <input id="examen" class="block mt-1 w-full form-control" type="text" name="examen" :value="old('examen')"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen'])->html();
} elseif ($_instance->childHasBeenRendered('0xyaooM')) {
    $componentId = $_instance->getRenderedChildComponentId('0xyaooM');
    $componentTag = $_instance->getRenderedChildComponentTagName('0xyaooM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0xyaooM');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen']);
    $html = $response->html();
    $_instance->logRenderedChild('0xyaooM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="opleiding_id" class="block font-medium text-sm text-gray-700">Opleiding</lable>
                        <select id="opleiding_id" class="block mt-1 w-full form-control" name="opleiding_id" :value="old('opleiding_id')">
                            <?php $__currentLoopData = $opleidingen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opleiding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($opleiding['id']); ?>"><?php echo e($opleiding['crebo_nr']); ?> // <?php echo e($opleiding['opleiding']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'opleiding_id'])->html();
} elseif ($_instance->childHasBeenRendered('Ec1OsB0')) {
    $componentId = $_instance->getRenderedChildComponentId('Ec1OsB0');
    $componentTag = $_instance->getRenderedChildComponentTagName('Ec1OsB0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Ec1OsB0');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'opleiding_id']);
    $html = $response->html();
    $_instance->logRenderedChild('Ec1OsB0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="geplande_docenten" class="block font-medium text-sm text-gray-700">Examinerende docenten</lable>
                        <input id="geplande_docenten" class="block mt-1 w-full form-control" type="varchar" name="geplande_docenten" :value="old('geplande_docenten')"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'geplande_docenten'])->html();
} elseif ($_instance->childHasBeenRendered('QjINyIE')) {
    $componentId = $_instance->getRenderedChildComponentId('QjINyIE');
    $componentTag = $_instance->getRenderedChildComponentTagName('QjINyIE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QjINyIE');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'geplande_docenten']);
    $html = $response->html();
    $_instance->logRenderedChild('QjINyIE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="opgeven_examen_begin" class="block font-medium text-sm text-gray-700">Opgeven examen begin</lable>
                        <input id="examen_opgeven_begin" class="block mt-1 w-full form-control" type="date" name="examen_opgeven_begin" :value="old('examen_opgeven_begin')"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_begin'])->html();
} elseif ($_instance->childHasBeenRendered('g6gmK8e')) {
    $componentId = $_instance->getRenderedChildComponentId('g6gmK8e');
    $componentTag = $_instance->getRenderedChildComponentTagName('g6gmK8e');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('g6gmK8e');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_begin']);
    $html = $response->html();
    $_instance->logRenderedChild('g6gmK8e', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="opgeven_examen_eind" class="block font-medium text-sm text-gray-700">Opgeven examen eind</lable>
                            <input id="examen_opgeven_eind" class="block mt-1 w-full form-control" type="date" name="examen_opgeven_eind" :value="old('examen_opgeven_eind')"/>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_eind'])->html();
} elseif ($_instance->childHasBeenRendered('WTG9qTX')) {
    $componentId = $_instance->getRenderedChildComponentId('WTG9qTX');
    $componentTag = $_instance->getRenderedChildComponentTagName('WTG9qTX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WTG9qTX');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_eind']);
    $html = $response->html();
    $_instance->logRenderedChild('WTG9qTX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <lable for="uitleg" class="block font-medium text-sm text-gray-700">Uitleg</lable>
                        <textarea id="uitleg" class="block mt-1 w-full form-control" type="text" name="uitleg" rows="4" :value="old('uitleg')"></textarea>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'uitleg'])->html();
} elseif ($_instance->childHasBeenRendered('CdBK2sC')) {
    $componentId = $_instance->getRenderedChildComponentId('CdBK2sC');
    $componentTag = $_instance->getRenderedChildComponentTagName('CdBK2sC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CdBK2sC');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'uitleg']);
    $html = $response->html();
    $_instance->logRenderedChild('CdBK2sC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="mt-4">
                    <a href="<?php echo e(route('examens.index')); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                        <i class="fas fa-backward mr-2"></i> Terug
                    </a>
                
                    <div class="form-group">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                            Opslaan <i class="fas fa-forward ml-2"></i> 
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </form>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('60By4y3')) {
    $componentId = $_instance->getRenderedChildComponentId('60By4y3');
    $componentTag = $_instance->getRenderedChildComponentTagName('60By4y3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('60By4y3');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('60By4y3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/examens/create.blade.php ENDPATH**/ ?>