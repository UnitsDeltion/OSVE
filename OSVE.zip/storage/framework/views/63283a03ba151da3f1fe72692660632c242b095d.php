<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php $__env->startSection('title', 'Gebruiker bewerken'); ?>
            <?php echo $__env->yieldContent('title'); ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.warning')->html();
} elseif ($_instance->childHasBeenRendered('tioIUsu')) {
    $componentId = $_instance->getRenderedChildComponentId('tioIUsu');
    $componentTag = $_instance->getRenderedChildComponentTagName('tioIUsu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tioIUsu');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.warning');
    $html = $response->html();
    $_instance->logRenderedChild('tioIUsu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-small-top')->html();
} elseif ($_instance->childHasBeenRendered('84NG0dl')) {
    $componentId = $_instance->getRenderedChildComponentId('84NG0dl');
    $componentTag = $_instance->getRenderedChildComponentTagName('84NG0dl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('84NG0dl');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-small-top');
    $html = $response->html();
    $_instance->logRenderedChild('84NG0dl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>" class="mt-10">

            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="mt-4">
                <div class="form-group">
                    <label for="voornaam" class="block font-medium text-sm text-gray-700">Voornaam</label>
                    <input id="voornaam" class="block mt-1 w-full form-control" type="text" name="voornaam" value="<?php echo e($user->voornaam); ?>" autofocus/>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'voornaam'])->html();
} elseif ($_instance->childHasBeenRendered('JSzTBiR')) {
    $componentId = $_instance->getRenderedChildComponentId('JSzTBiR');
    $componentTag = $_instance->getRenderedChildComponentTagName('JSzTBiR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JSzTBiR');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'voornaam']);
    $html = $response->html();
    $_instance->logRenderedChild('JSzTBiR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>  

                <div class="form-group">
                    <label for="achternaam" class="block font-medium text-sm text-gray-700">Achternaam</label>
                    <input id="achternaam" class="block mt-1 w-full form-control" type="text" name="achternaam" value="<?php echo e($user->achternaam); ?>"/>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'achternaam'])->html();
} elseif ($_instance->childHasBeenRendered('xo3nQIb')) {
    $componentId = $_instance->getRenderedChildComponentId('xo3nQIb');
    $componentTag = $_instance->getRenderedChildComponentTagName('xo3nQIb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xo3nQIb');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'achternaam']);
    $html = $response->html();
    $_instance->logRenderedChild('xo3nQIb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>

                <div class="form-group">
                    <label for="email" class="block font-medium text-sm text-gray-700">Email</label>
                    <input id="email" class="block mt-1 w-full form-control" type="email" name="email" value="<?php echo e($user->email); ?>"/>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'email'])->html();
} elseif ($_instance->childHasBeenRendered('37P5wBv')) {
    $componentId = $_instance->getRenderedChildComponentId('37P5wBv');
    $componentTag = $_instance->getRenderedChildComponentTagName('37P5wBv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('37P5wBv');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'email']);
    $html = $response->html();
    $_instance->logRenderedChild('37P5wBv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>

                <div class="form-group">
                    <label for="role" class="block font-medium text-sm text-gray-700">Rol</label>
                    <select id="role" name="role" class="form-select block font-medium text-sm text-gray-700" aria-label="Default select current">
                        <option
                            <?php if($user->isAn('opleidingsmanager')): ?>selected <?php endif; ?> value="3">Beheerder
                        </option>
                        <option 
                            <?php if($user->isAn('docent')): ?>selected <?php endif; ?> value="2">Docent
                        </option>
                    </select>
                </div>
                
                <div class="mt-4">
                    <a href="<?php echo e(route('users.index')); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                        <i class="fas fa-backward mr-2"></i> Terug
                    </a>
                    
                    <div class="form-group">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                            Opslaan <i class="fas fa-forward ml-2"></i> 
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </form>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('2VP2MiY')) {
    $componentId = $_instance->getRenderedChildComponentId('2VP2MiY');
    $componentTag = $_instance->getRenderedChildComponentTagName('2VP2MiY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2VP2MiY');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('2VP2MiY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/users/edit.blade.php ENDPATH**/ ?>