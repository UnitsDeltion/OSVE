<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex" style="width: 100%;">
            <h2 class="align-self-start font-semibold text-xl text-gray-800 leading-tight row">
                <?php $__env->startSection('title', 'Nieuwe gebruiker toevoegen'); ?>
                <?php echo $__env->yieldContent('title'); ?>
            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.warning')->html();
} elseif ($_instance->childHasBeenRendered('tDYzkmM')) {
    $componentId = $_instance->getRenderedChildComponentId('tDYzkmM');
    $componentTag = $_instance->getRenderedChildComponentTagName('tDYzkmM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tDYzkmM');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.warning');
    $html = $response->html();
    $_instance->logRenderedChild('tDYzkmM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-small-top')->html();
} elseif ($_instance->childHasBeenRendered('w5Vr4HZ')) {
    $componentId = $_instance->getRenderedChildComponentId('w5Vr4HZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('w5Vr4HZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('w5Vr4HZ');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-small-top');
    $html = $response->html();
    $_instance->logRenderedChild('w5Vr4HZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

        <form method="post" action="<?php echo e(route('users.store')); ?>" class="mt-10">
            
            <?php echo csrf_field(); ?>
            
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="voornaam" class="block font-medium text-sm text-gray-700">Voornaam</label>
                        <input id="voornaam" class="block mt-1 w-full form-control" type="text" name="voornaam" value="<?php echo e(old('voornaam')); ?>"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'voornaam'])->html();
} elseif ($_instance->childHasBeenRendered('7yiYNq3')) {
    $componentId = $_instance->getRenderedChildComponentId('7yiYNq3');
    $componentTag = $_instance->getRenderedChildComponentTagName('7yiYNq3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7yiYNq3');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'voornaam']);
    $html = $response->html();
    $_instance->logRenderedChild('7yiYNq3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>  

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="achternaam" class="block font-medium text-sm text-gray-700">Achternaam</label>
                        <input id="achternaam" class="block mt-1 w-full form-control" type="text" name="achternaam" value="<?php echo e(old('achternaam')); ?>"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'achternaam'])->html();
} elseif ($_instance->childHasBeenRendered('8iRE9aS')) {
    $componentId = $_instance->getRenderedChildComponentId('8iRE9aS');
    $componentTag = $_instance->getRenderedChildComponentTagName('8iRE9aS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8iRE9aS');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'achternaam']);
    $html = $response->html();
    $_instance->logRenderedChild('8iRE9aS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div> 

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="email" class="block font-medium text-sm text-gray-700">E-mail</label>
                        <input id="email" class="block mt-1 w-full form-control" type="email" name="email" value="<?php echo e(old('email')); ?>"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'email'])->html();
} elseif ($_instance->childHasBeenRendered('5NUw5f9')) {
    $componentId = $_instance->getRenderedChildComponentId('5NUw5f9');
    $componentTag = $_instance->getRenderedChildComponentTagName('5NUw5f9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5NUw5f9');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'email']);
    $html = $response->html();
    $_instance->logRenderedChild('5NUw5f9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div> 

                <div class="col-md-6 pr-2">
                    <div class="form-group">
                        <label for="password" class="block font-medium text-sm text-gray-700">Wachtwoord</label>
                        <input id="password" class="block mt-1 w-full form-control" type="password" name="password"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'password'])->html();
} elseif ($_instance->childHasBeenRendered('scX8uh6')) {
    $componentId = $_instance->getRenderedChildComponentId('scX8uh6');
    $componentTag = $_instance->getRenderedChildComponentTagName('scX8uh6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('scX8uh6');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'password']);
    $html = $response->html();
    $_instance->logRenderedChild('scX8uh6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div> 

                <div class="col-md-6 pl-2">
                    <div class="form-group">
                    <label for="passwordconfirm" class="block font-medium text-sm text-gray-700">Wachtwoord bevestiging</label>
                        <input id="passwordconfirm" class="block mt-1 w-full form-control" type="password" name="passwordconfirm"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'passwordconfirm'])->html();
} elseif ($_instance->childHasBeenRendered('VXkJTKh')) {
    $componentId = $_instance->getRenderedChildComponentId('VXkJTKh');
    $componentTag = $_instance->getRenderedChildComponentTagName('VXkJTKh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VXkJTKh');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'passwordconfirm']);
    $html = $response->html();
    $_instance->logRenderedChild('VXkJTKh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div> 

                <div class="mt-4">
                    <a href="<?php echo e(route('users.index')); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                        <i class="fas fa-backward mr-2"></i> Terug
                    </a>
                    
                    <div class="form-group">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                            Opslaan <i class="fas fa-forward ml-2"></i> 
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </form>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('1p4eBy2')) {
    $componentId = $_instance->getRenderedChildComponentId('1p4eBy2');
    $componentTag = $_instance->getRenderedChildComponentTagName('1p4eBy2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1p4eBy2');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('1p4eBy2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/users/create.blade.php ENDPATH**/ ?>