<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php $__env->startSection('title', 'Examen moment toevoegen'); ?>
            <?php echo $__env->yieldContent('title'); ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.warning')->html();
} elseif ($_instance->childHasBeenRendered('XJQvwEQ')) {
    $componentId = $_instance->getRenderedChildComponentId('XJQvwEQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('XJQvwEQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XJQvwEQ');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.warning');
    $html = $response->html();
    $_instance->logRenderedChild('XJQvwEQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('PjJAPaE')) {
    $componentId = $_instance->getRenderedChildComponentId('PjJAPaE');
    $componentTag = $_instance->getRenderedChildComponentTagName('PjJAPaE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PjJAPaE');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('PjJAPaE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

        <form method="post" action="<?php echo e(route('momentsStore', $examen['id'] )); ?>" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="datum" class="block font-medium text-sm text-gray-700">Datum</lable>
                        <input id="datum" class="block mt-1 w-full form-control" type="date" name="datum" :value="old('datum')"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'datum'])->html();
} elseif ($_instance->childHasBeenRendered('19MfZky')) {
    $componentId = $_instance->getRenderedChildComponentId('19MfZky');
    $componentTag = $_instance->getRenderedChildComponentTagName('19MfZky');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('19MfZky');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'datum']);
    $html = $response->html();
    $_instance->logRenderedChild('19MfZky', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="tijd" class="block font-medium text-sm text-gray-700">Tijdstippen</lable>
                        <input id="tijd" class="block mt-1 w-full form-control" type="time" name="tijd" :value="old('tijd')"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'tijd'])->html();
} elseif ($_instance->childHasBeenRendered('Sw00swN')) {
    $componentId = $_instance->getRenderedChildComponentId('Sw00swN');
    $componentTag = $_instance->getRenderedChildComponentTagName('Sw00swN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Sw00swN');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'tijd']);
    $html = $response->html();
    $_instance->logRenderedChild('Sw00swN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="plaatsen" class="block font-medium text-sm text-gray-700">Beschikbare plekken</lable>
                        <input id="plaatsen" class="block mt-1 w-full form-control" type="number" name="plaatsen" :value="old('plaatsen')"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'plaatsen'])->html();
} elseif ($_instance->childHasBeenRendered('7RqIFmi')) {
    $componentId = $_instance->getRenderedChildComponentId('7RqIFmi');
    $componentTag = $_instance->getRenderedChildComponentTagName('7RqIFmi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7RqIFmi');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'plaatsen']);
    $html = $response->html();
    $_instance->logRenderedChild('7RqIFmi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="geplande_docenten" class="block font-medium text-sm text-gray-700">Examinerende docenten</lable>
                        <input id="geplande_docenten" class="block mt-1 w-full form-control" type="varchar" name="geplande_docenten" :value="old('geplande_docenten')"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'geplande_docenten'])->html();
} elseif ($_instance->childHasBeenRendered('CBN4lZg')) {
    $componentId = $_instance->getRenderedChildComponentId('CBN4lZg');
    $componentTag = $_instance->getRenderedChildComponentTagName('CBN4lZg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CBN4lZg');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'geplande_docenten']);
    $html = $response->html();
    $_instance->logRenderedChild('CBN4lZg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="opgeven_examen_begin" class="block font-medium text-sm text-gray-700">Opgeven examen begin</lable>
                        <input id="examen_opgeven_begin" class="block mt-1 w-full form-control" type="date" name="examen_opgeven_begin" :value="old('examen_opgeven_begin')"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_begin'])->html();
} elseif ($_instance->childHasBeenRendered('FrNmQ1K')) {
    $componentId = $_instance->getRenderedChildComponentId('FrNmQ1K');
    $componentTag = $_instance->getRenderedChildComponentTagName('FrNmQ1K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FrNmQ1K');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_begin']);
    $html = $response->html();
    $_instance->logRenderedChild('FrNmQ1K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="opgeven_examen_eind" class="block font-medium text-sm text-gray-700">Opgeven examen eind</lable>
                            <input id="examen_opgeven_eind" class="block mt-1 w-full form-control" type="date" name="examen_opgeven_eind" :value="old('examen_opgeven_eind')"/>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_eind'])->html();
} elseif ($_instance->childHasBeenRendered('mJZiDum')) {
    $componentId = $_instance->getRenderedChildComponentId('mJZiDum');
    $componentTag = $_instance->getRenderedChildComponentTagName('mJZiDum');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mJZiDum');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_eind']);
    $html = $response->html();
    $_instance->logRenderedChild('mJZiDum', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>

                <div class="mt-4">
                    <a href="<?php echo e(route('examens.show', $examen['id'])); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                        <i class="fas fa-backward mr-2"></i> Terug
                    </a>
                    
                    <div class="form-group">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                            Opslaan <i class="fas fa-forward ml-2"></i> 
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </form>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('AeB0FmJ')) {
    $componentId = $_instance->getRenderedChildComponentId('AeB0FmJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('AeB0FmJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AeB0FmJ');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('AeB0FmJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/moments/create.blade.php ENDPATH**/ ?>