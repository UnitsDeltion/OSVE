<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php $__env->startSection('title', 'Opleiding bewerken'); ?>
            <?php echo $__env->yieldContent('title'); ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.warning')->html();
} elseif ($_instance->childHasBeenRendered('BEDc3pc')) {
    $componentId = $_instance->getRenderedChildComponentId('BEDc3pc');
    $componentTag = $_instance->getRenderedChildComponentTagName('BEDc3pc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BEDc3pc');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.warning');
    $html = $response->html();
    $_instance->logRenderedChild('BEDc3pc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('QQ8n6QV')) {
    $componentId = $_instance->getRenderedChildComponentId('QQ8n6QV');
    $componentTag = $_instance->getRenderedChildComponentTagName('QQ8n6QV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QQ8n6QV');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('QQ8n6QV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <form method="post" action="<?php echo e(route('opleidingen.update', $opleiding['id'])); ?>" class="mt-10">

            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="mt-4">
                <div class="form-group">
                    <label for="crebo_nr" class="block font-medium text-sm text-gray-700">Crebo nummer</label>
                    <input id="crebo_nr" class="block mt-1 w-full form-control" type="number" name="crebo_nr" value="<?php echo e($opleiding['crebo_nr']); ?>"/>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'crebo_nr'])->html();
} elseif ($_instance->childHasBeenRendered('nErhtNc')) {
    $componentId = $_instance->getRenderedChildComponentId('nErhtNc');
    $componentTag = $_instance->getRenderedChildComponentTagName('nErhtNc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nErhtNc');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'crebo_nr']);
    $html = $response->html();
    $_instance->logRenderedChild('nErhtNc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>

                <div class="form-group">
                    <label for="opleiding" class="block font-medium text-sm text-gray-700">Opleiding naam</label>
                    <input id="opleiding" class="block mt-1 w-full form-control" type="text" name="opleiding" value="<?php echo e($opleiding['opleiding']); ?>"/>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'opleiding'])->html();
} elseif ($_instance->childHasBeenRendered('HKRRqXo')) {
    $componentId = $_instance->getRenderedChildComponentId('HKRRqXo');
    $componentTag = $_instance->getRenderedChildComponentTagName('HKRRqXo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HKRRqXo');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'opleiding']);
    $html = $response->html();
    $_instance->logRenderedChild('HKRRqXo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>

                <div class="mt-4">
                    <a href="<?php echo e(route('opleidingen.index')); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                        <i class="fas fa-backward mr-2"></i> Terug
                    </a>
                    
                    <div class="form-group">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                            Opslaan <i class="fas fa-forward ml-2"></i> 
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
                
        </form>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('GOlu140')) {
    $componentId = $_instance->getRenderedChildComponentId('GOlu140');
    $componentTag = $_instance->getRenderedChildComponentTagName('GOlu140');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GOlu140');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('GOlu140', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/opleidingen/edit.blade.php ENDPATH**/ ?>