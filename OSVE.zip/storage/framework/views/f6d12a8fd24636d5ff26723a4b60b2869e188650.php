<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight r-title-big">
            Opgave systeem voor examens
        </h2>
        <h2 class="font-semibold text-xl text-gray-800 leading-tight r-title-small align-center">
            OSVE
        </h2>
     <?php $__env->endSlot(); ?>

    <div id="notify"></div>
    <?php $__errorArgs = ['examen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <script>
            Notify({
                type: 'danger',
                duration: 50000,
                position: 'top center',
                title: '<p class="align-center fc-secondary-nh mb-0">OSVE | Deltion College</p>',
                html: '<p class="align-center mb-0 fw-600 fc-primary-nh"><?php echo e($message); ?></p>',
            });
        </script>    
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('WisbuMf')) {
    $componentId = $_instance->getRenderedChildComponentId('WisbuMf');
    $componentTag = $_instance->getRenderedChildComponentTagName('WisbuMf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WisbuMf');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('WisbuMf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

        <script>
            $(function () {
                $('[data-toggle="tooltip"]').tooltip()
            })    
        </script>

        <div class="container">
            <div class="row">
                <form method="POST" action="<?php echo e(route('f4')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-40">
                        <h3>Examens</h3>

                        <?php if(!isset($examens[0])): ?>
                            <div class="mt-50">
                                <h3 class="align-center">Momenten zijn er geen examens ingepland.</h3>
                                <h5 class="align-center">Neem contact op met je docent voor meer informatie.</h5>
                            </div>
                        <?php else: ?>

                            <p class="fc-primary-nh mb-0-r">Kies uit de onderstaande lijst het juiste examen. Staat het juiste examen er niet bij? Neem dan contact op met je docent.</p>
                            <div class="container mb-10">
                                <div class="row justify-content-center">
                                    
                                    <?php $examenVak = ""; ?>
                                    <?php $__currentLoopData = $examens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            if($examen->vak != $examenVak ){
                                                if ($examenVak != ""){
                                                    echo "</div>";
                                                }
                
                                                echo "<div class=\"col-xs-12 col-sm-5 mr-10 ml-10 mt-20 p-3 shadow\">";
                                                echo "<h4 class=\"fc-secondary-nh\">" . $examen->vak . "</h4>";
                                            }
                                        
                                            $examenVak = $examen->vak;
                                        ?>
                                            <div class="row selectInput pb-1" onclick="selectInput('p3', <?php echo e($examen->id); ?>)">
                                                <div class="col-xs-9 col-9 fc-primary-nh">
                                                    <?php echo e($examen->examen); ?>

                                                </div>
                                                <div class="col-xs-1 col-1 examenInfo">
                                                    <i class="fas fa-info-circle align-center" id="tooltipFaciliteitenpas" data-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e($examen->uitleg); ?>"></i>
                                                </div>
                                                <div class="col-xs-1 col-1">
                                                    <input type="radio" class="radio-hide" name="examen" id="<?php echo e($examen->id); ?>" value="<?php echo e($examen->vak); ?> - <?php echo e($examen->examen); ?>">
                                                </div>
                                            </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                            </div>  

                        <?php endif; ?>
                    </div>

                    <div class="mt-4">
                        <a href="<?php echo e(route('p2')); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                            <i class="fas fa-backward mr-2"></i> Terug
                        </a>

                        <?php if(isset($examens[0])): ?>
                            <div class="form-group">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                                    Verder <i class="fas fa-forward ml-2"></i> 
                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('4Og6voW')) {
    $componentId = $_instance->getRenderedChildComponentId('4Og6voW');
    $componentTag = $_instance->getRenderedChildComponentTagName('4Og6voW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4Og6voW');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('4Og6voW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\School\PROJ\OSVE\resources\views/p3.blade.php ENDPATH**/ ?>