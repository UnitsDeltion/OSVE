<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight r-title-big">
            Opgave systeem voor examens
        </h2>
        <h2 class="font-semibold text-xl text-gray-800 leading-tight r-title-small align-center">
            OSVE
        </h2>
     <?php $__env->endSlot(); ?>

    <div id="notify"></div>
    <?php $__errorArgs = ['examenMoment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <script>
            Notify({
                type: 'danger',
                duration: 50000,
                position: 'top center',
                title: '<p class="align-center fc-secondary-nh mb-0">OSVE | Deltion College</p>',
                html: '<p class="align-center mb-0 fw-600 fc-primary-nh"><?php echo e($message); ?></p>',
            });
        </script>    
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('hFVStbO')) {
    $componentId = $_instance->getRenderedChildComponentId('hFVStbO');
    $componentTag = $_instance->getRenderedChildComponentTagName('hFVStbO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hFVStbO');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('hFVStbO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
    
        <div class="container">
            <div class="row">
                <form method="POST" action="<?php echo e(route('f5')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-40">
                        <h3>Examen moment</h3>

                        <?php if(!isset($examenMomenten[0])): ?>
                            <div class="mt-50">
                                <h3 class="align-center">Momenten zijn er geen examen momenten ingepland.</h3>
                                <h5 class="align-center">Neem contact op met je docent voor meer informatie.</h5>
                            </div>
                        <?php else: ?>
                            <p class="fc-primary-nh mb-0-r">Kies uit de onderstaande lijst het gewenste examen moment. Staat het juiste examen moment er niet bij? Neem dan contact op met je docent.</p>
                            <div class="container mb-10">
                                <div class="row justify-content-center">
                                    <?php $__errorArgs = ['examen_moment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="fc-red text-sm mb-2 text-center"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                    <h3 style="text-align: center" class="mt-3"><span class="fc-primary-nh"><?php echo e($vak); ?> <?php echo e($examen); ?></span></h3>

                                    <div class="container mb-10">
                                        <div class="row justify-content-center">

                                            <?php $examenDatum = "";
                                            foreach($examenMomenten as $examen){
                                                
                                                    $timestamp = strtotime($examen->datum);
                                                    $examenDatumFormatted = date('d-m-Y', strtotime($examen->datum)); 

                                                    if($examen->plaatsen >= 1){
                                                        
                                                        $timestamp = strtotime($examen->datum);
                                                        $examenDatumFormatted = date('d-m-Y', strtotime($examen->datum)); 

                                                            $day = date('l', $timestamp);
                                                            switch($day){
                                                                case "Monday":
                                                                    $day = "Maandag";
                                                                    break;
                                                                case "Tuesday":
                                                                    $day = "Dinsdag";
                                                                    break;
                                                                case "Wednesday":
                                                                    $day = "Woensdag";
                                                                    break;
                                                                case "Thursday":
                                                                    $day = "Donderdag";
                                                                    break;
                                                                case "Friday":
                                                                    $day = "Vrijdag";
                                                                    break;
                                                                case "Saturday":
                                                                    $day = "Zaterdag";
                                                                    break;
                                                                case "Sunday":
                                                                    $day = "Zondag";
                                                                    break;
                                                            }

                                                        if($examen->datum != $examenDatum ){
                                                            if ($examenDatum != ""){
                                                                echo "</div>";
                                                            }
                                                            echo "<div class=\"col-xs-12 col-sm-5 mr-10 ml-10 mt-20 p-3 shadow\">";
                                                            echo "<div class=\"row\"><div class=\"col-7 col-xs-8 col-sm-12 col-md-7\"><h4 class=\"fc-secondary-nh\">" . $day . "</h4></div><div class=\"col-5 col-xs-4 col-sm-12 p4-date col-md-5 ta-right \"><small>(" . $examenDatumFormatted . ")</small></div></div>";
                                                        }
                                                        
                                                        $examenDatum = $examen->datum;    
                                                    }      
                                                ?>

                                                    <div class="row selectInput pb-1" onclick="selectInput('p4', <?php echo e($examen->id); ?>)">
                                                        <div class="col-sm-12 row" title="Resterende aantal plaatsen">
                                                            <span class="col-5 col-sm-5 col-md-5 col-lg-7"> <?php echo e(date('H:i', strtotime($examen->tijd))); ?> </span>
                                                            <span class="col-5 col-sm-5 col-md-5 col-lg-3 text-align-end"><i class="far fa-user fc-secondary"></i> <?php echo e($examen->plaatsen); ?></span>
                                                            <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                                                <input type="radio" name="examenMoment" id="<?php echo e($examen->id); ?>" value="<?php echo e($examen->datum); ?> - <?php echo e($examen->tijd); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                            <?php
                                                }    
                                            ?>  
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    </div>

                    <div class="mt-4">
                        <a href="<?php echo e(route('p3')); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                            <i class="fas fa-backward mr-2"></i> Terug
                        </a>

                        <?php if(isset($examenMomenten)): ?>
                            <div class="form-group">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                                    Verder <i class="fas fa-forward ml-2"></i> 
                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('XWpXZ6d')) {
    $componentId = $_instance->getRenderedChildComponentId('XWpXZ6d');
    $componentTag = $_instance->getRenderedChildComponentTagName('XWpXZ6d');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XWpXZ6d');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('XWpXZ6d', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\School\PROJ\OSVE\resources\views/p4.blade.php ENDPATH**/ ?>