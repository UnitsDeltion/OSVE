
<form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
    <div class="modal-body">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <h5 class="text-center">Weet je het zeker dat je de gebruiker <span class="fc-secondary">"<?php echo e($user->voornaam); ?> <?php echo e($user->achternaam); ?>"</span> wilt verwijderen?</h5>
    </div>
    <div class="modal-footer-custom">
            <div class="mt-4">
                <a data-bs-dismiss="modal" class="pointer fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                    <i class="fas fa-backward mr-2" ></i> Annuleer
                </a>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button float-right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button float-right']); ?>
                    Ja, verwijder de gebruiker <i class="fas fa-forward ml-2"></i> 
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
    </div>
</form><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/users/delete.blade.php ENDPATH**/ ?>