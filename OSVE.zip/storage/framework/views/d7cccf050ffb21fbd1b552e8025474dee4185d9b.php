<div>
    <?php $__errorArgs = [$input];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
        <script>
            document.getElementById('<?php echo e($input); ?>').classList.add("bc-red", "sh-red"); 
            document.getElementById('<?php echo e($input); ?>').classList.remove("shadow-sm"); 
        </script>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\School\PROJ\OSVE\resources\views/livewire/includes/validation/input.blade.php ENDPATH**/ ?>