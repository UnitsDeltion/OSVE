<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.warning')->html();
} elseif ($_instance->childHasBeenRendered('yE1rBCt')) {
    $componentId = $_instance->getRenderedChildComponentId('yE1rBCt');
    $componentTag = $_instance->getRenderedChildComponentTagName('yE1rBCt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yE1rBCt');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.warning');
    $html = $response->html();
    $_instance->logRenderedChild('yE1rBCt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-wide-top')->html();
} elseif ($_instance->childHasBeenRendered('In7x3mI')) {
    $componentId = $_instance->getRenderedChildComponentId('In7x3mI');
    $componentTag = $_instance->getRenderedChildComponentTagName('In7x3mI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('In7x3mI');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-wide-top');
    $html = $response->html();
    $_instance->logRenderedChild('In7x3mI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

        <div class="pagination justify-content-center">
            <a href="#1" class="activePage" id="pagButtonOne" title="Studenten" onclick="pagination('1')"><i class="fas fa-user-graduate"></i> Ingeplande examens</a>
            <a href="#2" class="" id="pagButtonTwo" title="Docenten" onclick="pagination('2')"><i class="fas fa-chalkboard-teacher"></i> Alle examens</a>
            <a href="#3" class="" id="pagButtonThree" title="Klassen" onclick="pagination('3')"><i class="fas fa-school"></i> Opleidingen</a>
        </div>

        <br>

        <div id="elementOne">
            <h3>Ingeplande examens</h3>
            <table class="table table-bordered" style="margin: 10px 0 10px 0;" id="ingeplandeExamens">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Faciliteitenpas</th>
                        <th>Klas</th>
                        <th>Examen</th>
                        <th>Datum</th>
                        <th>Tijd</th>
                        <th>Student bevestigd</th>
                        <th>Docent bevestigd</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $geplandeExamens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geplandExamen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($geplandExamen->voornaam); ?> <?php echo e($geplandExamen->achternaam); ?> <small>(<?php echo e($geplandExamen->studentnummer); ?>)</small>
                        </td>
                        <td>
                            <?php echo e($geplandExamen->faciliteitenpas); ?>

                        </td>
                        <td>
                            <?php echo e($geplandExamen->klas); ?>

                        </td>
                        <td>
                            <?php echo e($geplandExamen->vak); ?> <?php echo e($geplandExamen->gepland_examen); ?>

                        </td>
                        <td>
                            <?php echo e(date('d-m-Y', strtotime($geplandExamen['datum']))); ?>

                        </td>
                        <td>
                            <?php echo e(date('H:i', strtotime($geplandExamen['tijd']))); ?>

                        </td>
                        <td>
                            <?php if($geplandExamen->std_bevestigd == '1'): ?>
                                <p class="fc-primary-nh">Bevestigd</p>
                            <?php else: ?>
                                <p class="fc-secondary-nh" title="Examen is nog niet bevestigd door de student">Niet bevestigd</p>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($geplandExamen->doc_bevestigd == '1'): ?>
                                <p class="fc-primary-nh">Bevestigd</p>
                            <?php else: ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','id' => 'button'.e($geplandExamen->id).'','onclick' => 'selectInput(\'dashboard\', \'examenBevestigen\', \''.e($geplandExamen->id).'\')']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','id' => 'button'.e($geplandExamen->id).'','onclick' => 'selectInput(\'dashboard\', \'examenBevestigen\', \''.e($geplandExamen->id).'\')']); ?>
                                    Selecteren
                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody> 
            </table>

            <form action="<?php echo e(route('bevestigExamen')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="examenBevestigen" id="examenBevestigen" value="">

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button']); ?>
                    Examens bevestigen
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </form>
        </div>

        <div id="elementTwo" style="display: none;">
            <h3>Actieve examens</h3>
            <p>Active examens zijn examens waarbij vandaag een examen moment is ingepland.</p>
            <table class="table table-bordered" style="margin: 10px 0 10px 0;" id="actieveExamens">
                <thead>
                    <tr>
                        <th>Vak</th>
                        <th>Examen</th>
                        <th>Vak docent</th>
                        <th>Geplande docent</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $activeExamens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeExamen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($activeExamen->vak); ?>

                            </td>
                            <td>
                                <?php echo e($activeExamen->examen); ?>

                            </td>
                            <td>
                                <?php echo e($activeExamen->vak_docent); ?>

                            </td>
                            <td>
                                <?php echo e($activeExamen->geplande_docenten); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <hr>

            <h3>Alle examens</h3>
                <div class="row">
                    <div class="col-sm-6 form-group">
                        <label for="min">Eerste datum</label>
                        <input type="text" class="form-control" id="min" name="min" placeholder="Eerst datum">
                    </div>
                </div>
    
            <table class="table table-bordered" style="margin: 10px 0 10px 0;" id="toekomstigeExamens">
                <thead>
                    <tr>
                        <th>Vak</th>
                        <th>Examen</th>
                        <th>Vak docent</th>
                        <th>Eerste datum</th>
                        <th>Laatste datum</th>
                    </tr>
                </thead>
                    
                <tbody>
                    <?php $__currentLoopData = $examens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($examen->vak); ?>

                            </td>
                            <td>
                                <?php echo e($examen->examen); ?>

                            </td>
                            <td>
                                <?php echo e($examen->vak_docent); ?>

                            </td>
                            <td id="min">
                                <?php echo e($examen->startDatum); ?>

                            </td>
                            <td id="max">
                                <?php echo e($examen->eindDatum); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div id="elementThree" style="display: none;">
            <h3>Opleidingen</h3>
            <table class="table table-bordered" style="margin: 10px 0 10px 0;" id="opleidingen">
                <thead>
                    <tr>
                        <th>Crebo nummer</th>
                        <th>Opleiding</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $opleidingen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opleiding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($opleiding->crebo_nr); ?>

                        </td>
                        <td>
                            <?php echo e($opleiding->opleiding); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<script>
    var minDate, maxDate;
 
    $.fn.dataTable.ext.search.push(
        function( settings, data, dataIndex ) {
            var min = minDate.val();
            var max = maxDate.val();
            var date = new Date( data[3] );
            if (
                ( min === null && max === null ) ||
                ( min === null && mdate <= max ) ||
                ( min <= date   && max === null ) ||
                ( min <= date   && date <= max )
            ) {
                return true;
            }
            return false;
        }
    );

    $(document).ready(function() {
        $('#ingeplandeExamens').DataTable( {
            "language": {
                "url": "<?php echo e(asset('/beheer/json/datatabels/dutch')); ?>",
            },
            dom: 'Bfrtip',
        
            buttons: [
                'excel', {
                
                extend: 'pdfHtml5',
                customize: function(doc) {
                    doc.defaultStyle.alignment = 'right';
                    doc.styles.tableHeader.color = 'white';
                    doc.styles.tableHeader.fillColor = '#F58220';
                },
            
                download: 'open',
                exportOptions: {
                    modifier: {
                        page: 'current'
                    }
                }},
            ]
            ,
        
            
        });
        $('#actieveExamens').DataTable( {
            "language": {
                "url": "<?php echo e(asset('/beheer/json/datatabels/dutch')); ?>"
            }
        });


        $('#toekomstigeExamens').DataTable( {
            "language": {
                "url": "<?php echo e(asset('/beheer/json/datatabels/dutch')); ?>"
            },
        });
        $('#opleidingen').DataTable( {
            "language": {
                "url": "<?php echo e(asset('/beheer/json/datatabels/dutch')); ?>"
            }
        });
    });

    $(document).ready(function() {
        // Create date inputs
        minDate = new DateTime($('#min'), {
            format: 'MMMM Do YYYY'
        });
        maxDate = new DateTime($('#max'), {
            format: 'MMMM Do YYYY'
        });
    
        // DataTables initialisation
        var table = $('#toekomstigeExamens').DataTable();
    
        // Refilter the table
        $('#min, #max').on('change', function () {
            table.draw();
        });
    });
</script><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/dashboard/index.blade.php ENDPATH**/ ?>