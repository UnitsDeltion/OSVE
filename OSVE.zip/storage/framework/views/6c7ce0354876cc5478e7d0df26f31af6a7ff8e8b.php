<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex" style="width: 100%;">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php $__env->startSection('title', 'Examen'); ?>
                <?php echo $__env->yieldContent('title'); ?>
            </h2>
            <a href="<?php echo e(route('momentsCreate', $examen['id'])); ?>" class="a-clear" style="margin-right: 10px; margin-left: auto;">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['title' => 'moment','class' => 'button']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'moment','class' => 'button']); ?>
                    <?php echo e(__('Examen moment aanmaken')); ?>

                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </a>
                <a href="<?php echo e(route('examens.edit', $examen['id'])); ?>" class="a-clear">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['title' => 'Bewerken','class' => 'button']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Bewerken','class' => 'button']); ?>
                        <?php echo e(__('Examen bewerken')); ?>

                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </a>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('tFYnyYM')) {
    $componentId = $_instance->getRenderedChildComponentId('tFYnyYM');
    $componentTag = $_instance->getRenderedChildComponentTagName('tFYnyYM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tFYnyYM');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('tFYnyYM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mb-10" role="alert">
                <p class="mb-0"><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="mt-4">
                <a href="<?php echo e(route('examens.index')); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                    <i class="fas fa-backward mr-2"></i> Terug
                </a>
            </div>
        </div>
        
        <form method="get" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="vak" class="block font-medium text-sm text-gray-700">Vak</label>
                        <input id="vak" class="block mt-1 w-full form-control" type="text" name="vak" value="<?php echo e($examen['vak']); ?>" disabled/>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="examen" class="block font-medium text-sm text-gray-700">Examen</label>
                        <input id="examen" class="block mt-1 w-full form-control" type="text" name="examen" value="<?php echo e($examen['examen']); ?>" disabled/>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="opleiding_id" class="block font-medium text-sm text-gray-700">Opleiding</label>
                        <select id="opleiding_id" class="block mt-1 w-full form-control" name="opleiding_id" value="<?php echo e($examen['opleiding_id']); ?>" disabled>
                            <?php $__currentLoopData = $opleidingen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opleiding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($opleiding['id']); ?>" 
                                <?php if($opleiding['id'] == $examen['opleiding_id']){echo 'selected';} ?>
                                ><?php echo e($opleiding['opleiding']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="vak_docent" class="block font-medium text-sm text-gray-700">Vak docent</label>
                        <input id="vak_docent" class="block mt-1 w-full form-control" type="text" name="vak_docent" value="<?php echo e($examen['vak_docent']); ?>" disabled/>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="uitleg" class="block font-medium text-sm text-gray-700">Uitleg</label>
                        <textarea id="uitleg" class="block mt-1 w-full form-control" type="text" name="uitleg" rows="4"  disabled><?php echo e($examen['uitleg']); ?></textarea>
                    </div>
                </div>

            </div>
        </form>

        <h4 class="fc-secondary">Examen momenten</h4>

        <table class="table fz-14 br-5">
            <thead>
                <tr>
                    <th>Datum</th>
                    <th>Tijd</th>
                    <th>Plaatsen</th>
                    <th colspan="2"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $examen['examen_moments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 text-sm text-gray-900">
                        <?php echo e(date('d-m-Y', strtotime($moment['datum']))); ?>

                        </td>
                        <td class="px-6 text-sm text-gray-900">
                        <?php echo e(date('H:i', strtotime($moment['tijd']))); ?>

                            
                        </td>
                        <td>
                            <?php echo e($moment['plaatsen']); ?>

                        </td>
                        <td class="align-right pr-0">
                            <a class="a-clear" href="<?php echo e(route('moments.edit', $moment['id'])); ?>">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['title' => 'edit','class' => 'mb-2 mr-2 button']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'edit','class' => 'mb-2 mr-2 button']); ?>
                                    <i class="fas fa-edit"></i>
                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </a>

                            <a class="a-clear" data-toggle="modal" id="largeButton" data-target="#largeModal" data-attr="<?php echo e(route('momentsDelete', $moment['id'])); ?>" title="Delete Moment">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','title' => 'Verwijderen']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','title' => 'Verwijderen']); ?>
                                        <i class="fas fa-trash"></i>
                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

<div class="modal fade" id="largeModal" data-bs-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="largeBody">
                <div>
                    <!-- body content -->
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // display delete modal
    $(document).on('click', '#largeButton', function(event) {
        event.preventDefault();
        let href = $(this).attr('data-attr');
        $.ajax({
            url: href
            , beforeSend: function() {
                $('#loader').show();
            },
            // return the result
            success: function(result) {
                $('#largeModal').modal("show");
                $('#largeBody').html(result).show();
            }
            , complete: function() {
                $('#loader').hide();
            }
            , error: function(jqXHR, testStatus, error) {
                console.log(error);
                alert("Page " + href + " cannot open. Error:" + error);
                $('#loader').hide();
            }
            , timeout: 8000
        })
    });

</script>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('UcmNqUZ')) {
    $componentId = $_instance->getRenderedChildComponentId('UcmNqUZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('UcmNqUZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UcmNqUZ');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('UcmNqUZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/examens/show.blade.php ENDPATH**/ ?>