<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

    <?php
        $route = Route::current();
        $name = $route->getName();
    ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.breadcrumbs', ['page' => $name])->html();
} elseif ($_instance->childHasBeenRendered('BaPXNQq')) {
    $componentId = $_instance->getRenderedChildComponentId('BaPXNQq');
    $componentTag = $_instance->getRenderedChildComponentTagName('BaPXNQq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BaPXNQq');
} else {
    $response = \Livewire\Livewire::mount('includes.breadcrumbs', ['page' => $name]);
    $html = $response->html();
    $_instance->logRenderedChild('BaPXNQq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="content"><?php /**PATH C:\School\PROJ\OSVE\resources\views/livewire/includes/content/top/content-small-top.blade.php ENDPATH**/ ?>