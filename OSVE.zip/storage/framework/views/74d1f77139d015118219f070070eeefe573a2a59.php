<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php $__env->startSection('title', 'Examen moment bewerken'); ?>
            <?php echo $__env->yieldContent('title'); ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.warning')->html();
} elseif ($_instance->childHasBeenRendered('zNJ975J')) {
    $componentId = $_instance->getRenderedChildComponentId('zNJ975J');
    $componentTag = $_instance->getRenderedChildComponentTagName('zNJ975J');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zNJ975J');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.warning');
    $html = $response->html();
    $_instance->logRenderedChild('zNJ975J', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.top.content-normal-top')->html();
} elseif ($_instance->childHasBeenRendered('CEWzWpR')) {
    $componentId = $_instance->getRenderedChildComponentId('CEWzWpR');
    $componentTag = $_instance->getRenderedChildComponentTagName('CEWzWpR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CEWzWpR');
} else {
    $response = \Livewire\Livewire::mount('includes.content.top.content-normal-top');
    $html = $response->html();
    $_instance->logRenderedChild('CEWzWpR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

        <form method="post" action="<?php echo e(route('moments.update', $moment['id'] )); ?>" enctype="multipart/form-data">

            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="datum" class="block font-medium text-sm text-gray-700">Datum</lable>
                        <input id="datum" class="block mt-1 w-full form-control" type="date" name="datum" value="<?php echo e($moment['datum']); ?>"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'datum'])->html();
} elseif ($_instance->childHasBeenRendered('Jh1a0c7')) {
    $componentId = $_instance->getRenderedChildComponentId('Jh1a0c7');
    $componentTag = $_instance->getRenderedChildComponentTagName('Jh1a0c7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Jh1a0c7');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'datum']);
    $html = $response->html();
    $_instance->logRenderedChild('Jh1a0c7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="tijd" class="block font-medium text-sm text-gray-700">Tijdstip</lable>
                        <input id="tijd" class="block mt-1 w-full form-control" type="time" name="tijd" value="<?php echo e($moment['tijd']); ?>"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'tijd'])->html();
} elseif ($_instance->childHasBeenRendered('PtyBRAf')) {
    $componentId = $_instance->getRenderedChildComponentId('PtyBRAf');
    $componentTag = $_instance->getRenderedChildComponentTagName('PtyBRAf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PtyBRAf');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'tijd']);
    $html = $response->html();
    $_instance->logRenderedChild('PtyBRAf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="plaatsen" class="block font-medium text-sm text-gray-700">Beschikbare plekken</lable>
                        <input id="plaatsen" class="block mt-1 w-full form-control" type="number" name="plaatsen" value="<?php echo e($moment['plaatsen']); ?>"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'plaatsen'])->html();
} elseif ($_instance->childHasBeenRendered('WQeyrvs')) {
    $componentId = $_instance->getRenderedChildComponentId('WQeyrvs');
    $componentTag = $_instance->getRenderedChildComponentTagName('WQeyrvs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WQeyrvs');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'plaatsen']);
    $html = $response->html();
    $_instance->logRenderedChild('WQeyrvs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="geplande_docenten" class="block font-medium text-sm text-gray-700">Examinerende docenten</lable>
                        <input id="geplande_docenten" class="block mt-1 w-full form-control" type="varchar" name="geplande_docenten" value="<?php echo e($moment['geplande_docenten']); ?>"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'geplande_docenten'])->html();
} elseif ($_instance->childHasBeenRendered('psDJ86H')) {
    $componentId = $_instance->getRenderedChildComponentId('psDJ86H');
    $componentTag = $_instance->getRenderedChildComponentTagName('psDJ86H');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('psDJ86H');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'geplande_docenten']);
    $html = $response->html();
    $_instance->logRenderedChild('psDJ86H', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <lable for="opgeven_examen_begin" class="block font-medium text-sm text-gray-700">Opgeven examen begin</lable>
                        <input id="examen_opgeven_begin" class="block mt-1 w-full form-control" type="date" name="examen_opgeven_begin" value="<?php echo e($moment['examen_opgeven_begin']); ?>"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_begin'])->html();
} elseif ($_instance->childHasBeenRendered('FmlT2xf')) {
    $componentId = $_instance->getRenderedChildComponentId('FmlT2xf');
    $componentTag = $_instance->getRenderedChildComponentTagName('FmlT2xf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FmlT2xf');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_begin']);
    $html = $response->html();
    $_instance->logRenderedChild('FmlT2xf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
                        
                <div class="col-md-6">
                    <div class="form-group">
                    <lable for="opgeven_examen_eind" class="block font-medium text-sm text-gray-700">Opgeven examen eind</lable>
                        <input id="examen_opgeven_eind" class="block mt-1 w-full form-control" type="date" name="examen_opgeven_eind" value="<?php echo e($moment['examen_opgeven_eind']); ?>"/>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_eind'])->html();
} elseif ($_instance->childHasBeenRendered('M6YYwW5')) {
    $componentId = $_instance->getRenderedChildComponentId('M6YYwW5');
    $componentTag = $_instance->getRenderedChildComponentTagName('M6YYwW5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('M6YYwW5');
} else {
    $response = \Livewire\Livewire::mount('includes.validation.input', ['input' => 'examen_opgeven_eind']);
    $html = $response->html();
    $_instance->logRenderedChild('M6YYwW5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

                <div class="mt-4">
                    <a href="<?php echo e(route('examens.show', $examen['id'])); ?>" class="fc-h-white a-clear float-left mb-2 button inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition button float-right">
                        <i class="fas fa-backward mr-2"></i> Terug
                    </a>
                    
                    <div class="form-group">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'button','style' => 'float: right']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'button','style' => 'float: right']); ?>
                            Opslaan <i class="fas fa-forward ml-2"></i> 
                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </form>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('includes.content.bottom.content-bottom')->html();
} elseif ($_instance->childHasBeenRendered('MaLuEF5')) {
    $componentId = $_instance->getRenderedChildComponentId('MaLuEF5');
    $componentTag = $_instance->getRenderedChildComponentTagName('MaLuEF5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MaLuEF5');
} else {
    $response = \Livewire\Livewire::mount('includes.content.bottom.content-bottom');
    $html = $response->html();
    $_instance->logRenderedChild('MaLuEF5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\School\PROJ\OSVE\resources\views/beheer/moments/edit.blade.php ENDPATH**/ ?>